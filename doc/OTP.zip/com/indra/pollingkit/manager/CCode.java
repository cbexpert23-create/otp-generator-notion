package com.indra.pollingkit.manager;

import java.util.Calendar;
import java.util.Date;

import android.annotation.SuppressLint;
import android.content.Context;

import com.indra.pollingkit.db.CManager;
import com.indra.pollingkit.db.DBGlobals;

@SuppressLint("DefaultLocale")
public class CCode {
	private int LARGO_10 = 14;
	private int LARGO_BASE = 10;
	private int ENCRIPT_BASE = 26;
	private String CHAR_0 = "0";
	private String CHAR_a = "A";
	private String lista = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private Context m_context;

	public CCode(Context pContext) {
		try {
			m_context = pContext;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * Decode 10 length passcode into 16 length string
	 * 
	 * @param pPassCode
	 *            : passcode to decode
	 * @param pPS
	 *            : PS from passcode
	 * @return the code if it is correct and match with pPS param
	 */
	public String decodePassCode(String pPassCode, int pPS) {
		try {
			pPassCode = pPassCode.toUpperCase();
			String sOut = Decodificar(pPassCode);
			sOut = DecodificarFecha(sOut);
			if (checkDC(sOut)) {
				String sPS = sOut.substring(3, 9) + sOut.substring(1, 3);
				if (sPS.equals(Integer.toString(pPS)))
					return sOut;
				else
					return "";
			} else
				return "";
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	/**
	 * Comprueba si el passCode es de la PS y del día del mes.
	 * 
	 * @param pPassCode
	 * @param pPS
	 * @param pDay
	 *            @ return 	5 Acción SuperAdmin 
	 *            		   	0 Acción Admin 
	 *            			-1 Acción errónea
	 *            			-2 No corresponde a la PS 
	 *            			-3 PassCode ya utilizado
	 */
	public int checkPassCode(String pPassCode, int pPS) {
		try {
			CManager CM = new CManager(m_context);
			boolean bExists = CM.existsPassCode(pPassCode);
			CM.close();
			if (bExists) {
				return -3;
			} else {
				String sCode = decodePassCode(pPassCode, pPS);
				if (sCode.equals(""))
					return -2;
				else {
					return actionFromPassCodeDecoded(sCode);
				}
			}
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	/**
	 * Generate 10 length passcode from 8 length PS code
	 * 
	 * @param pCode
	 * @return
	 */
	@SuppressLint("DefaultLocale")
	public String generatePassCode(String pPS, String pAction) {
		try {
			// Genera una cadena compuesta por
			// PS 2 digitos polling station
			// PC 6 digitos polling center
			// DD 2 digitos dia del mes
			// HH 2 digitos hora
			// MM 2 digitos minuto
			// AC 1 digito acción (0: admin; 5: superadmin)
			// A la cadena resultante le añade por delante un dígito de control,
			// checksum del resto
			// La cadena resultante de 16 dígitos se deja en 14
			// transformando los seis de DDHHMM en cinco del minuto del mes
			// y codificando AC dentro del primer dígito de la fecha resultante
			// tal y como se explica en el siguiente comentario más abajo.
			String PS = pPS.substring(6, 8);
			String PC = pPS.substring(0, 6);
			Calendar cal1 = Calendar.getInstance();
			cal1.setTime(new Date());
			String dia = String.format("%02d", cal1.get(Calendar.DAY_OF_MONTH));
			String hora = String.format("%02d", cal1.get(Calendar.HOUR_OF_DAY));
			String minuto = String.format("%02d", cal1.get(Calendar.MINUTE));
			String sPassCode = PS + PC + dia + hora + minuto + pAction;
			String DC = generateDC(sPassCode);
			sPassCode = DC + sPassCode;

			String fecha = minutoDelMes(dia, hora, minuto);

			// La acción se codifica junto con el primer digito de la fecha,
			// dado que el primer
			// digito de la fecha nunca sera mayor que 4, y la acción es 0 ò 5.
			// Para decodificar la fecha, si este dígito es mayor que 4 habrá
			// que restarle 5, y será acción de superadmin.
			// Si este primer dígito es menor que 4, la acción es 0, admin.
			int s1 = CUtils.parseInt(fecha.substring(0, 1));
			String s2 = fecha.substring(1, 5);
			s1 = s1 + CUtils.parseInt(pAction);

			sPassCode = DC + PS + PC + Integer.toString(s1) + s2;
			sPassCode = Codificar(sPassCode);

			return sPassCode;
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	/**
	 * Generate 6 length pincode from 8 length PS code
	 * 
	 * @param pCode
	 * @return
	 */
	public static String generatePINCode(String pPS) {
		try {
			String sOut = toLenght6(pPS);
			int rep = checkSum(sOut);
			for (int i = 0; i < rep; i++)
				sOut = ofuscateCode(sOut);
			return sOut;
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	/**
	 * Check if DC match with pPassCode
	 * 
	 * @param pPassCode
	 * @return
	 */
	public boolean checkDC(String pPassCode) {
		try {
			String dc = generateDC(pPassCode.substring(1, pPassCode.length()));
			return dc.equals(pPassCode.substring(0, 1));
		} catch (Exception ex) {
			return false;
		}
	}

	/**
	 * Return the action codified into a valid PassCode decoded
	 * 
	 * @param pPassCode
	 * @return 1 for Admin, 2 for SuperAdmin
	 */
	private int actionFromPassCodeDecoded(String pPassCode) {
		try {
			if (pPassCode.length() != 16)
				return -1;
			else {
				String accion = pPassCode.substring(15, 16);
				if (accion.equals(DBGlobals.AC_ADMIN)
						|| accion.equals(DBGlobals.AC_SUPERADMIN))
					return CUtils.parseInt(accion);
				else
					return -1;
			}
		} catch (Exception ex) {
			return -1;
		}
	}

	/**
	 * Return the Polling Station code codified into a valid PassCode decoded
	 * 
	 * @param pPassCode
	 * @return
	 */
	public int pollingStationFromPassCodeDecoded(String pPassCode) {
		try {
			if (pPassCode.length() != 16)
				return -1;
			else
				return CUtils.parseInt(pPassCode.substring(3, 9)
						+ pPassCode.substring(1, 3));
		} catch (Exception ex) {
			return -1;
		}
	}

	/**
	 * Encode number pText (length = 14) from decimal to base LARGO_BASE (length
	 * = 10)
	 * 
	 * @param pText
	 * @return
	 */
	private String Codificar(String pText) {
		try {
			int i;
			String sOut = "";
			long l;

			int len;
			// El largo de la cadena debe ser múltiplo de LARGO_10
			len = pText.length() % LARGO_10;
			if (len != 0) {
				for (i = LARGO_10; i > len; i--)
					pText = pText + CHAR_0;
			}

			i = 0;
			while (i < pText.length()) {
				l = Long.parseLong(pText.substring(i, LARGO_10));
				i = i + LARGO_10;
				sOut = sOut + FromBase10WithFormat(l);
			}
			return sOut;
		} catch (Exception ex) {
			return "";
		}
	}

	/**
	 * Decode number pText (length = 10) from base LARGO_BASE to decimal number
	 * (length = 14)
	 * 
	 * @param pText
	 * @return
	 */
	private String Decodificar(String pText) {
		try {
			String sOut = "";
			int i = 0;
			int len;

			// El largo de la cadena debe ser múltiplo de LARGO_BASE
			len = pText.length() % LARGO_BASE;
			if (len != 0) {
				for (i = LARGO_BASE; i > len; i--)
					pText = pText + CHAR_a;
			}

			String formato = "";
			for (i = 0; i < LARGO_10; i++)
				formato = formato + CHAR_0;
			i = 0;

			while (i < pText.length()) {
				sOut = sOut
						+ ToBase10WithFormat(pText.substring(i, i + LARGO_BASE))
								.toString();
				i = i + LARGO_BASE;
			}
			return sOut;
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage());
		}
	}

	private String generateDC(String pText) {
		try {
			String dc = "";
			long suma = 0;
			for (int i = 0; i < pText.length(); i++) {
				suma = suma + Long.parseLong(pText.substring(i, i + 1));
			}
			dc = Long.toString(suma);
			if (dc.length() > 1)
				dc = generateDC(dc);
			return dc;
		} catch (Exception ex) {
			return "";
		}
	}

	private String DecodificarFecha(String pText) {
		try {
			String DC = pText.substring(0, 1);
			String PS = pText.substring(1, 3);
			String PC = pText.substring(3, 9);
			int fecha1 = CUtils.parseInt(pText.substring(9, 10));
			int fecha2 = CUtils.parseInt(pText.substring(10, 14));
			String accion;
			if (fecha1 >= 5) {
				accion = DBGlobals.AC_SUPERADMIN;
				fecha1 = fecha1 - 5;
			} else
				accion = DBGlobals.AC_ADMIN;

			int fecha = fecha1 * 10000 + fecha2;
			int minuto = fecha % 60;
			fecha = fecha - minuto;
			fecha = fecha / 60;
			int hora = fecha % 24;
			fecha = fecha - hora;
			fecha = fecha / 24;
			int dia = fecha + 1;

			String sFecha = String.format("%02d", dia)
					+ String.format("%02d", hora)
					+ String.format("%02d", minuto);

			String sOut = DC + PS + PC + sFecha + accion;

			return sOut;
		} catch (Exception ex) {
			return "";
		}
	}

	private String minutoDelMes(String pDia, String pHora, String pMinuto) {
		String fecha = Integer.toString((CUtils.parseInt(pDia) - 1) * 24 * 60
				+ CUtils.parseInt(pHora) * 60 + CUtils.parseInt(pMinuto));
		int len = fecha.length();
		if (len < 5) {
			for (int i = len; i < 5; i++)
				fecha = "0" + fecha;
		}
		return fecha;
	}

	private String FromBase10WithFormat(long b) {
		String sOut = "";
		int i = 0;
		sOut = FromBase10(b);
		int len = sOut.length();
		for (i = len; i < LARGO_BASE; i++)
			sOut = CHAR_a + sOut;
		return sOut;
	}

	private String FromBase10(long b) {
		String sOut = "";
		if (b < ENCRIPT_BASE) {
			int ib = (int) b;
			sOut = lista.substring(ib, ib + 1);
		} else {
			long lo = b / ENCRIPT_BASE;
			sOut = FromBase10(lo) + FromBase10(b % ENCRIPT_BASE);
		}
		return sOut;
	}

	private Long ToBase10(String pText) {
		int i = 0;
		int j = 0;
		long l = 0;
		for (i = pText.length(); i > 0; i--) {
			j = lista.indexOf(pText.substring(i - 1, i), 0);
			l = l + j * (long) Math.pow(ENCRIPT_BASE, (pText.length() - i));
		}
		return l;
	}

	private String ToBase10WithFormat(String pText) {
		String sOut = "";
		int i = 0;
		sOut = Long.toString(ToBase10(pText));
		int len = sOut.length();
		for (i = len; i < LARGO_10; i++)
			sOut = CHAR_0 + sOut;
		return sOut;
	}

	private static String toLenght6(String pPS) {
		try {
			String p1 = pPS.substring(0, 1) + pPS.substring(4, 5);
			String p2 = pPS.substring(3, 4) + pPS.substring(1, 2)
					+ pPS.substring(2, 3) + pPS.substring(7, 8)
					+ pPS.substring(5, 6);
			switch (CUtils.parseInt(p1)) {
			case 10:
				p1 = "0";
				break;
			case 11:
				p1 = "1";
				break;
			case 12:
				p1 = "2";
				break;
			case 20:
				p1 = "3";
				break;
			case 21:
				p1 = "4";
				break;
			case 30:
				p1 = "5";
				break;
			case 31:
				p1 = "6";
				break;
			case 40:
				p1 = "7";
				break;
			case 50:
				p1 = "8";
				break;
			default:
				p1 = "9";
				break;
			}
			return p2 + p1;
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	private static int checkSum(String pCode) {
		try {
			int nSum = 0;
			for (int i = 0; i < pCode.length(); i++)
				nSum = nSum + CUtils.parseInt(pCode.substring(i, i + 1));
			String sSum = Integer.toString(nSum);
			if (sSum.length() > 1)
				return checkSum(sSum);
			else
				return nSum;
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}

	private static String ofuscateCode(String pCode) {
		try {
			//String[] sLine = { "4", "6", "8", "2", "9", "0", "5", "3", "7", "1" };
			String[] sLine = {  "6", "2", "0", "8", "1", "4", "7", "9", "3", "5"};
			// Asegurarse de que tiene longitud 6
			for (int i = pCode.length(); i < 6; i++)
				pCode = pCode + "0";
			String sOut = "";
			for (int i = 0; i < 6; i++) {
				int pos = CUtils.parseInt(pCode.substring(i, i + 1));
				sOut = sOut + sLine[pos];
			}
			return sOut;
		} catch (Exception ex) {
			throw new RuntimeException(ex);
		}
	}
}
